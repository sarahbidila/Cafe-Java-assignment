public class CafeJava {
    public static void main(String[] args) {
        // APP VARIABLES
        // Lines of text that will appear in the app. 
        String generalGreeting = "Welcome to Cafe Java, ";
        String pendingMessage = ", your order will be ready shortly";
        String readyMessage = ", your order is ready";
        String displayTotalMessage = "Your total is $";
        
        // Menu variables (add yours below)
        double mochaPrice = 3.5;
        double dripPrice = 3.8;
        double lattePrice = 5.5;
        double cappucinoPrice = 9.4;
    
        // Customer name variables (add yours below)
        String customer1 = "Cindhuri";
        String customer2 = "Noah";
        String customer3 = "Jimmy";
        String customer4 = "Sam ";
    
        // Order completions (add yours below)
        boolean isReadyOrder1 = false;
        boolean isReadyOrder2 = true;
        boolean isReadyOrder3 = true;
        boolean isReadyOrder4 = false;
    
        // APP INTERACTION SIMULATION (Add your code for the challenges below)
        // Example:
        System.out.println(generalGreeting + customer1); // Displays "Welcome to Cafe Java, Cindhuri"
        System.out.println(customer1 + pendingMessage);
    	// ** Your customer interaction print statements will go here ** //
        //for Noah
        if(isReadyOrder2 == false){
            System.out.println(customer2 + pendingMessage);
    
        }else{
        System.out.println(customer2 + readyMessage);
        System.out.println(displayTotalMessage + cappucinoPrice);
        }

        //for Sam
        System.out.println (customer4 + displayTotalMessage + (2*lattePrice));
        //if statement for Sam
        if(isReadyOrder4){
            System.out.println(customer4 + readyMessage);
        }else{
            System.out.println(customer4 + pendingMessage);
        }

        //Jimmy's order
        System.out.println(customer3 + readyMessage);
        System.out.println (displayTotalMessage + (lattePrice - dripPrice));
    }
}
